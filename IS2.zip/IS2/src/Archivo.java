import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("6cc6708e-2ab4-410d-a1aa-6bb7feb9e4e7")
public class Archivo {
    @objid ("0acd0ff9-3d57-4f78-a129-cff30613ab59")
    private String Nombre;

    @objid ("7159047d-9950-48d5-8775-76cc562f1d31")
    private String TipoArchivo;

    @objid ("72d1fac0-651e-4731-bb62-907de66a3ecb")
    private Date Fecha;

    @objid ("7b191e58-f1c8-4601-b69f-3cbfdb0c42ca")
    public Alumno alumno;

}
