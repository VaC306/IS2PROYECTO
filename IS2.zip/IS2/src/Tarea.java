import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("4cfbdff9-4314-4d1f-8715-5d1685bd1fff")
public class Tarea {
    @objid ("043a75d1-7379-4890-8d3a-3a50b6e1019f")
    private Date FechaEntrega;

    @objid ("9d0d68a8-75bc-41e7-9bea-b4153d9cb6dd")
    private float Nota;

    @objid ("33577c21-f572-40ca-a325-f85820b420c3")
    private boolean Entregado;

    @objid ("bea8d82d-105e-4a34-b2a8-d84a30e43c44")
    private boolean Calificado;

    @objid ("610e2825-1ca5-456d-bdb6-9cb795d8e9cd")
    private Archivo archivo;

}
