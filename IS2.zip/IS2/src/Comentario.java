import java.util.Date;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("73966c99-98cc-4644-8953-fb3a5dc05cd2")
public class Comentario {
    @objid ("4aee957e-dcbe-4537-9765-e09f0699270a")
    private String mensaje;

    @objid ("2d08034a-1724-40de-b06b-4ca6202b2f1c")
    private Date fecha;

    @objid ("f7394909-cd42-4e51-bda2-70ff1bfb4a6d")
    private boolean visto;

}
